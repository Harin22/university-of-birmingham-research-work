# Taylor bubble flow > 2025-10-15 7:43pm
https://universe.roboflow.com/uni-project-ifxad/taylor-bubble-flow-fddxm

Provided by a Roboflow user
License: CC BY 4.0

